﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coronel.Hernan._2A
{
    public class Perro:Mascota
    {
        private int _edad;
        public int Edad
        {
            get { return _edad; }
            set { _edad = value; }
        }

        private bool _esAlfa;
        public bool EsAlfa
        {
            get { return _esAlfa; }
            set { _esAlfa = value; }
        }

        public Perro(string nombre, string raza)
        {
            this._nombre = nombre;
            this._raza = raza;
        }

        public Perro(string nombre, string raza,int edad, bool esAlfa)
            : this(nombre, raza)
        {
            this.Edad = edad;
            this.EsAlfa = esAlfa;
        }
   

        protected override string Ficha()
        {
            if (_esAlfa)
                return this.ToString()+", alfa de la manada";

            return "Nombre: " + this.Nombre + ", cruza, edad:" + this.Edad;
        }

        public override string ToString()
        {
            StringBuilder obj = new StringBuilder();

            obj.AppendLine(DatosCompletos() + " Edad: " + this.Edad);

            return obj.ToString();
        }

        public static implicit operator int(Perro obj)
        {
            return obj.Edad;
        }


        public override bool Equals(object obj)
        {
            return (obj==this);
        }

        public static bool operator ==(Perro p1,Perro p2)
        {
            return (p1.Nombre == p2.Nombre && p1.Raza == p2.Raza && p1.Edad == p2.Edad);
        }

        public static bool operator !=(Perro p1, Perro p2)
        {
            return !(p1.Nombre == p2.Nombre && p1.Raza == p2.Raza && p1.Edad == p2.Edad);
        }
    }
}
