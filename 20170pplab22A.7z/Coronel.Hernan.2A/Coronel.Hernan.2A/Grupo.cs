﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coronel.Hernan._2A
{
    public class Grupo
    {
        private static List<Mascota> _manada;
        private string _nombre;

        private TipoManada _tipo;
        public TipoManada Tipo
        {
            set { _tipo = value; }
        }

        public Grupo()
        {
            this.Tipo = TipoManada.Unica;
        }

        static Grupo()
        {
            _manada = new List<Mascota>();
        }

        public Grupo(string nombre):this()
        {
            this._nombre = nombre;
        }

        public Grupo(string nombre, TipoManada tipo):this(nombre)
        {
            this.Tipo = tipo;
        }

        public static implicit operator string(Grupo e)
        {
            StringBuilder obj = new StringBuilder();

            obj.AppendLine("**"+e._nombre+" "+e._tipo+"**");
            foreach (Mascota item in _manada)
            {
                obj.AppendLine(item.ToString());
            }
            return obj.ToString();
        }

        public static bool operator ==(Grupo a, Mascota b)
        {
            foreach (Mascota item in _manada)
            {
                if (item == b)
                    return true;
            }
            return false;
        }

        public static bool operator !=(Grupo a, Mascota b)
        {
            return !(a==b);
        }

        public static Grupo operator +(Grupo a, Mascota b)
        {
            if (a != b)
                _manada.Add(b);
            return a;
        }

        public static Grupo operator -(Grupo a, Mascota b)
        {
            if (a == b)
                _manada.Remove(b);

            return a;

        }
    }

    public enum TipoManada
    {
        Unica,
        Mixta
    }
}
