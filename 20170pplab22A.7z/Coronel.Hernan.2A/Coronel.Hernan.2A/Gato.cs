﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coronel.Hernan._2A
{
    public class Gato:Mascota
    {

        public Gato(string nombre, string raza)
        {
            this._nombre = nombre;
            this._raza = raza;
        }

        public override bool Equals(object obj)
        {
            return (obj==this);
        }

        protected override string Ficha()
        {
            return this.ToString();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        public static bool operator ==(Gato p1, Gato p2)
        {
            return (p1.Nombre == p2.Nombre && p1.Raza == p2.Raza);
        }

        public static bool operator !=(Gato p1, Gato p2)
        {
            return !(p1.Nombre == p2.Nombre && p1.Raza == p2.Raza);
        }

    }
}
