﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coronel.Hernan._2A
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
