﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coronel.Hernan._2A
{
    public abstract class Mascota
    {
        protected string _nombre;
        protected string Nombre
        {
            get { return _nombre; }
        }

        protected string _raza;
        protected string Raza
        {
            get { return _raza; }
        }

        protected abstract string Ficha();

        protected virtual string DatosCompletos()
        {            
            return string.Format("Nombre: {0} Raza: {1}",this.Nombre,this.Raza);
        }
    }
}
